package com.example.freetv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private val Red = Color(0xFFE40000)
private val Gold = Color(0xFFFFC107)
private val Bg = Color(0xFF0E0E12)
private val Card = Color(0xFF1B1B22)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red)) { App() }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    Box(Modifier.fillMaxSize().background(Bg)) {
        Browse(vm)
        if (vm.playing) PlayerScreen(vm)
    }
}

@Composable
fun Browse(vm: MainViewModel) {
    val shown by remember { derivedStateOf { vm.visible() } }
    val sugg by remember { derivedStateOf { vm.suggestions() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Free TV", color = Color.White, fontSize = 26.sp)
            Spacer(Modifier.width(24.dp))
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                singleLine = true,
                placeholder = { Text("Search channels") },
                modifier = Modifier.weight(1f)
            )
        }

        if (sugg.isNotEmpty() && !(sugg.size == 1 && sugg[0].equals(vm.query.trim(), true))) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(top = 10.dp)
            ) {
                items(sugg) { s -> Chip(s, false) { vm.query = s } }
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(vertical = 12.dp)
        ) {
            items(Tab.values().toList()) { t ->
                Chip(t.label, selected = t == vm.tab && vm.query.isBlank()) { vm.selectTab(t) }
            }
        }

        val loadingTab = vm.query.isBlank() && vm.tab.url != null && vm.lists[vm.tab] == null
        when {
            loadingTab && vm.tab in vm.failed -> Column {
                Text("Couldn't load channels. Check your internet connection.", color = Color.White)
                Spacer(Modifier.height(10.dp))
                Chip("Retry", false) { vm.retry() }
            }
            loadingTab -> Text("Loading channels…", color = Color.Gray)
            shown.isEmpty() -> Text(
                if (vm.query.isNotBlank()) "No channels match your search."
                else "No favourites yet. Hold OK on any channel to add it here.",
                color = Color.Gray
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(180.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(shown, key = { it.url }) { c ->
                    ChannelCard(
                        c,
                        fav = c in vm.favs || vm.isFav(c),
                        onPlay = { vm.play(shown, shown.indexOf(c)) },
                        onFav = { vm.toggleFav(c) }
                    )
                }
            }
        }
        if (shown.isNotEmpty()) {
            Text(
                "OK = watch   ·   hold OK = add/remove ★ favourite",
                color = Color.Gray, fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .background(if (selected) Red else Color(0xFF2A2A33))
            .border(if (f) 3.dp else 0.dp, Color.White, shape)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Text(text, color = Color.White, maxLines = 1) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChannelCard(c: Channel, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .clip(shape)
            .onFocusChanged { f = it.isFocused }
            .combinedClickable(onClick = onPlay, onLongClick = onFav)
            .background(if (f) Color(0xFF2C2C36) else Card)
            .border(if (f) 3.dp else 0.dp, Color.White, shape)
            .padding(8.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color(0xFF14141A))) {
            if (c.logo.isEmpty()) {
                Text(
                    c.name.take(1).uppercase(), color = Color.Gray, fontSize = 32.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                AsyncImage(
                    model = c.logo, contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(8.dp)
                )
            }
            if (fav) Text("★", color = Gold, fontSize = 20.sp, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        Text(
            c.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val ch = vm.queue.getOrNull(vm.playIndex) ?: return
    val ctx = LocalContext.current
    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(15_000)
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
    }
    var error by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(true) }
    val focus = remember { FocusRequester() }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { error = true }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) error = false
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    LaunchedEffect(ch.url) {
        error = false
        player.setMediaItem(MediaItem.fromUri(ch.url))
        player.prepare()
        player.playWhenReady = true
        showInfo = true
        delay(4000)
        showInfo = false
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    BackHandler { vm.stop() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) false
                else when (e.key) {
                    Key.DirectionUp, Key.ChannelDown -> { vm.step(-1); true }
                    Key.DirectionDown, Key.ChannelUp -> { vm.step(1); true }
                    Key.DirectionCenter, Key.Enter -> { showInfo = !showInfo; true }
                    Key.Menu -> { vm.toggleFav(ch); showInfo = true; true }
                    else -> false
                }
            }
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { showInfo = !showInfo }
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    keepScreenOn = true
                    this.player = player
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (buffering && !error) CircularProgressIndicator(Modifier.align(Alignment.Center))
        if (error) Text(
            "This stream isn't available right now.\nPress ▲ / ▼ to try another channel.",
            color = Color.White, modifier = Modifier.align(Alignment.Center)
        )
        if (showInfo || error) {
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Color(0xCC000000)).padding(24.dp)
            ) {
                Text((if (vm.isFav(ch)) "★ " else "") + ch.name, color = Color.White, fontSize = 22.sp)
                Text(
                    "▲ ▼ change channel   ·   Menu = ★ favourite   ·   Back = channel list",
                    color = Color.Gray, fontSize = 13.sp
                )
            }
        }
    }
}
