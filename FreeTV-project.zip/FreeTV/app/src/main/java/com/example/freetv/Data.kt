package com.example.freetv

data class Channel(
    val name: String,
    val url: String,
    val logo: String = "",
    val group: String = ""
)

/** Tabs. Playlists come from the public iptv-org project (freely available channels). */
enum class Tab(val label: String, val url: String?) {
    FAVOURITES("★ Favourites", null),
    INDIA("India", "https://iptv-org.github.io/iptv/countries/in.m3u"),
    TAMIL("Tamil", "https://iptv-org.github.io/iptv/languages/tam.m3u"),
    NEWS("News", "https://iptv-org.github.io/iptv/categories/news.m3u"),
    MOVIES("Movies", "https://iptv-org.github.io/iptv/categories/movies.m3u"),
    MUSIC("Music", "https://iptv-org.github.io/iptv/categories/music.m3u"),
    KIDS("Kids", "https://iptv-org.github.io/iptv/categories/kids.m3u"),
    SPORTS("Sports", "https://iptv-org.github.io/iptv/categories/sports.m3u"),
    CRICKET("Cricket", null)
}

object M3u {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""
        var logo = ""
        var group = ""
        var pending = false
        for (raw in text.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXTINF")) {
                val a = attr.findAll(l).associate { it.groupValues[1] to it.groupValues[2] }
                logo = a["tvg-logo"] ?: ""
                group = a["group-title"] ?: ""
                name = l.substringAfterLast(",").trim()
                pending = true
            } else if (pending && l.isNotEmpty() && !l.startsWith("#")) {
                out.add(Channel(name.ifEmpty { "Unknown" }, l, logo, group))
                pending = false
            }
        }
        return out.distinctBy { it.url }.sortedBy { it.name.lowercase() }
    }
}
