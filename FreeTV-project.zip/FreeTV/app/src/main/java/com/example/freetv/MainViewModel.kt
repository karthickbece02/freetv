package com.example.freetv

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("freetv", Context.MODE_PRIVATE)

    var tab by mutableStateOf(Tab.INDIA); private set
    var query by mutableStateOf("")
    val lists = mutableStateMapOf<Tab, List<Channel>>()
    val failed = mutableStateListOf<Tab>()
    var favs by mutableStateOf(readFavs()); private set

    var queue by mutableStateOf<List<Channel>>(emptyList()); private set
    var playIndex by mutableIntStateOf(0); private set
    var playing by mutableStateOf(false); private set

    init {
        viewModelScope.launch {
            load(Tab.INDIA)
            Tab.values().filter { it.url != null && it != Tab.INDIA }.forEach { load(it) }
        }
    }

    fun selectTab(t: Tab) {
        tab = t
        query = ""
        if (t.url != null && lists[t] == null) retry()
    }

    fun retry() {
        failed.remove(tab)
        viewModelScope.launch { load(tab) }
    }

    private suspend fun load(t: Tab) {
        val url = t.url ?: return
        val file = File(getApplication<Application>().cacheDir, "${t.name}.m3u")
        if (lists[t] == null) {
            val cached = withContext(Dispatchers.IO) {
                if (file.exists()) runCatching { M3u.parse(file.readText()) }.getOrNull() else null
            }
            if (!cached.isNullOrEmpty()) lists[t] = cached
        }
        val fresh = withContext(Dispatchers.IO) {
            runCatching {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10_000
                c.readTimeout = 20_000
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                file.writeText(txt)
                M3u.parse(txt)
            }.getOrNull()
        }
        if (!fresh.isNullOrEmpty()) lists[t] = fresh
        else if (lists[t] == null && t !in failed) failed.add(t)
    }

    // ---- search ----
    fun visible(): List<Channel> {
        val q = query.trim()
        if (q.isEmpty()) return when (tab) {
            Tab.FAVOURITES -> favs
            Tab.CRICKET -> (lists[Tab.SPORTS].orEmpty() + lists[Tab.INDIA].orEmpty())
                .filter { it.name.contains("cricket", true) || it.name.contains("willow", true) || it.name.contains("ten ", true) }
                .distinctBy { it.url }
            else -> lists[tab].orEmpty()
        }
        return (favs + lists.values.flatten())
            .distinctBy { it.url }
            .filter { it.name.contains(q, ignoreCase = true) }
            .sortedBy { if (it.name.startsWith(q, ignoreCase = true)) 0 else 1 }
    }

    fun suggestions(): List<String> {
        val q = query.trim()
        if (q.length < 1) return emptyList()
        return (favs + lists.values.flatten())
            .map { it.name }
            .distinct()
            .filter { it.contains(q, ignoreCase = true) }
            .sortedBy { if (it.startsWith(q, ignoreCase = true)) 0 else 1 }
            .take(6)
    }

    // ---- favourites ----
    fun isFav(c: Channel) = favs.any { it.url == c.url }

    fun toggleFav(c: Channel) {
        favs = if (isFav(c)) favs.filter { it.url != c.url } else favs + c
        prefs.edit().putString("favs", favs.joinToString("\n") {
            listOf(it.name, it.url, it.logo, it.group).joinToString("\t") { s -> s.replace("\t", " ").replace("\n", " ") }
        }).apply()
    }

    private fun readFavs(): List<Channel> =
        prefs.getString("favs", "").orEmpty().lines().mapNotNull {
            val p = it.split("\t")
            if (p.size >= 4) Channel(p[0], p[1], p[2], p[3]) else null
        }

    // ---- playback ----
    fun play(list: List<Channel>, index: Int) {
        queue = list
        playIndex = index
        playing = true
    }

    fun step(d: Int) {
        if (queue.isEmpty()) return
        playIndex = (playIndex + d + queue.size) % queue.size
    }

    fun stop() { playing = false }
}
