# Free TV (Android TV app for Airtel Xstream Box)

Channels come from the public iptv-org playlists (freely available streams).
Edit the `Tab` enum in `Data.kt` to add/replace playlist URLs.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

## Install on the box
- Enable Developer options (Settings > Device Preferences > About > tap Build 7x) and USB/network debugging.
- `adb connect <box-ip>:5555` then `adb install app-debug.apk`
- Or copy the APK with a "Send files to TV" app / USB drive and open it with a file manager.

## Remote controls
- Grid: arrows to move, OK = play, hold OK = favourite
- Player: Up/Down = previous/next channel, OK = show info, Menu = favourite, Back = list
